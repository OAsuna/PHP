<?php
session_start();
include "conn.php";
$user = $_POST['user'];
$pwd = $_POST['pwd'];
$sql = "SELECT * FROM `admin` WHERE `name` = '{$user}' and `pwd` = '{$pwd}' ";

$stmt= $conn->query($sql);
$result = mysqli_fetch_array($stmt);

if($stmt->num_rows > 0){
    $_SESSION['user'] = $result[0];
    echo "<script>alert(\"登录成功！\")</script>";
    echo "<script>window.location.href='index.php'</script>";
}
else 
{
    echo "<script>alert(\"账号或密码错误，请重新输入！\")</script>";
    echo "<script>window.location.href='login.html'</script>";
}