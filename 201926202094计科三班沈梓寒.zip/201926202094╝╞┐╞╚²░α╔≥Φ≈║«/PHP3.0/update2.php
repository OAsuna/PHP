<?php
include "conn.php";
$user = $_POST['user'];
$id = $_POST['id'];
$gender = $_POST['gender'];
$phone = $_POST['phone'];
$class = $_POST['class'];
//根据学号来修改信息
// $rows = "select `id` from `student` where `id` = '{$id}' and `user` = '{$user}'";
$rows = "select `id` from `student` where `id` = '{$id}'";
$stmt1= $conn->query($rows);
$row = mysqli_num_rows($stmt1);
if ($row != 1){
    echo "<script>alert('学号输入错误，请重新输入！')</script>";
    echo ("<script>window.location.href='index.php'</script>");
}else{
    $sql = "update `student` set `user` = '{$user}',`gender` = '{$gender}',`phone` = '{$phone}',`class` = '{$class}' where `id` = '{$id}'";
    $stmt= $conn->query($sql);
    if ($stmt > 0){
        echo ("<script>alert('修改成功')</script>");
        echo ("<script>window.location.href='index.php'</script>");
    }else {
        echo ("<script>alert('修改失败')</script>");
        echo ("<script>window.location.href='index.php'</script>");
    }
}

$conn->close();

