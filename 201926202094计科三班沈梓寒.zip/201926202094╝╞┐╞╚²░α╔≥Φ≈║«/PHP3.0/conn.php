<?php
$servername = "localhost";
$username = "root";
$password = "root";
$tab = "work";

// 创建连接

$conn = new mysqli("localhost", "root","root","work");
$conn->query("SET NAMES 'UTF8'");

// 检测连接
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}



