/*
Navicat MySQL Data Transfer

Source Server         : shen
Source Server Version : 50726
Source Host           : localhost:3306
Source Database       : work

Target Server Type    : MYSQL
Target Server Version : 50726
File Encoding         : 65001

Date: 2021-12-20 09:16:47
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `admin`
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `name` varchar(20) NOT NULL,
  `pwd` varchar(20) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('admin', 'admin');
INSERT INTO `admin` VALUES ('shen', '123456');

-- ----------------------------
-- Table structure for `student`
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `user` varchar(50) NOT NULL,
  `id` varchar(10) NOT NULL,
  `gender` char(2) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `class` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('辛烷', '001', '女', '123123', '123123');
INSERT INTO `student` VALUES ('命脉', '002', '男', '149658745', '1808班');
INSERT INTO `student` VALUES ('恶灵', '003', '女', '15874569852', '1807班');
INSERT INTO `student` VALUES ('幻想', '004', '男', '15489758462', '1807班');
INSERT INTO `student` VALUES ('亡灵', '005', '男', '15478965412', '1808班');
INSERT INTO `student` VALUES ('瓦基', '006', '男', '16895423685', '1808班');
INSERT INTO `student` VALUES ('寻血犬', '007', '男', '15634387453', '1354班');
INSERT INTO `student` VALUES ('电妹', '100', '女', '1235135131', '10班');
INSERT INTO `student` VALUES ('屁男', '120', '男', '1385431313', '1353班');
INSERT INTO `student` VALUES ('辛烷玩', '123', '男', '123123', '1231231');
